import os
from torch.utils.data import DataLoader, Dataset
from torchvision.datasets import ImageFolder

from .transforms import build_train_transform, build_eval_transform


def build_dataset(cfg: dict, split: str = "train") -> Dataset:
   
    data_cfg = cfg["data"]
    img_size = cfg["model"]["img_size"]
    task = data_cfg.get("task", "classification")

    if task == "classification":
        key = "train_dir" if split == "train" else "val_dir"
        transform = (
            build_train_transform(
                img_size=img_size,
                use_rand_augment=data_cfg.get("rand_augment", True),
                rand_augment_config=data_cfg.get("rand_augment_config", "rand-m9-mstd0.5-inc1"),
                random_erasing_prob=data_cfg.get("random_erasing_prob", 0.25),
            )
            if split == "train"
            else build_eval_transform(img_size=img_size)
        )
        return ImageFolder(data_cfg[key], transform=transform)

    raise ValueError(
        f"Unknown task '{task}'. For segmentation/pose, use mmcv/mmpose pipelines directly."
    )


def build_loader(cfg: dict, split: str = "train") -> DataLoader:
    
    dataset = build_dataset(cfg, split)
    data_cfg = cfg["data"]
    batch_size = cfg["training"]["batch_size"]

    return DataLoader(
        dataset,
        batch_size=batch_size if split == "train" else batch_size * 2,
        shuffle=(split == "train"),
        num_workers=data_cfg.get("num_workers", 8),
        pin_memory=data_cfg.get("pin_memory", True),
        drop_last=(split == "train"),
        persistent_workers=data_cfg.get("num_workers", 8) > 0,
    )
