import random
import math
import numpy as np
import torch
import torch.nn.functional as F
import torchvision.transforms as T
from torchvision.transforms import InterpolationMode


IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD  = (0.229, 0.224, 0.225)


def build_train_transform(
    img_size: int = 224,
    use_rand_augment: bool = True,
    rand_augment_config: str = "rand-m9-mstd0.5-inc1",
    random_erasing_prob: float = 0.25,
) -> T.Compose:
    
    transforms = [
        T.RandomResizedCrop(img_size, interpolation=InterpolationMode.BICUBIC),
        T.RandomHorizontalFlip(),
    ]

    if use_rand_augment:
        try:
            from timm.data.auto_augment import rand_augment_transform
            transforms.append(rand_augment_transform(rand_augment_config, {}))
        except ImportError:
            transforms.append(T.ColorJitter(0.4, 0.4, 0.4))

    transforms += [
        T.ToTensor(),
        T.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD),
    ]

    if random_erasing_prob > 0:
        transforms.append(T.RandomErasing(p=random_erasing_prob))

    return T.Compose(transforms)


def build_eval_transform(img_size: int = 224, crop_pct: float = 0.875) -> T.Compose:
    
    scale_size = int(math.floor(img_size / crop_pct))
    return T.Compose([
        T.Resize(scale_size, interpolation=InterpolationMode.BICUBIC),
        T.CenterCrop(img_size),
        T.ToTensor(),
        T.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD),
    ])


class MixupCutmix:
    
    def __init__(
        self,
        mixup_alpha: float = 0.8,
        cutmix_alpha: float = 1.0,
        prob: float = 1.0,
        num_classes: int = 1000,
        switch_prob: float = 0.5,
    ):
        self.mixup_alpha = mixup_alpha
        self.cutmix_alpha = cutmix_alpha
        self.prob = prob
        self.num_classes = num_classes
        self.switch_prob = switch_prob

    def _one_hot(self, targets: torch.Tensor) -> torch.Tensor:
        return F.one_hot(targets, self.num_classes).float()

    def _mixup(
        self, images: torch.Tensor, targets: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        lam = np.random.beta(self.mixup_alpha, self.mixup_alpha)
        idx = torch.randperm(images.size(0), device=images.device)
        mixed = lam * images + (1 - lam) * images[idx]
        soft = lam * self._one_hot(targets) + (1 - lam) * self._one_hot(targets[idx])
        return mixed, soft

    def _cutmix(
        self, images: torch.Tensor, targets: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        lam = np.random.beta(self.cutmix_alpha, self.cutmix_alpha)
        B, C, H, W = images.shape
        idx = torch.randperm(B, device=images.device)

        cut_ratio = math.sqrt(1.0 - lam)
        cut_h = int(H * cut_ratio)
        cut_w = int(W * cut_ratio)
        cx = random.randint(0, W)
        cy = random.randint(0, H)
        x1, x2 = max(cx - cut_w // 2, 0), min(cx + cut_w // 2, W)
        y1, y2 = max(cy - cut_h // 2, 0), min(cy + cut_h // 2, H)

        images = images.clone()
        images[:, :, y1:y2, x1:x2] = images[idx, :, y1:y2, x1:x2]
        lam_actual = 1.0 - (y2 - y1) * (x2 - x1) / (H * W)
        soft = lam_actual * self._one_hot(targets) + (1 - lam_actual) * self._one_hot(targets[idx])
        return images, soft

    def __call__(
        self, images: torch.Tensor, targets: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if random.random() > self.prob:
            return images, self._one_hot(targets)

        use_cutmix = (self.cutmix_alpha > 0) and (
            random.random() < self.switch_prob or self.mixup_alpha == 0
        )
        if use_cutmix:
            return self._cutmix(images, targets)
        return self._mixup(images, targets)
