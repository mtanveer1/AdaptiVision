from setuptools import setup, find_packages

setup(
    name="adaptivision",
    version="1.0.0",
    description="AdaptiVision: A Flexible and Efficient Vision Transformer for Adaptive Token Pruning",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "torch>=2.0.0",
        "torchvision>=0.15.0",
        "timm>=0.9.0",
        "einops>=0.6.0",
        "numpy>=1.23.0",
        "pyyaml>=6.0",
        "tqdm>=4.64.0",
        "tensorboard>=2.12.0",
        "fvcore>=0.1.5",
    ],
    extras_require={
        "seg": ["mmcv-full>=2.0.0", "mmsegmentation>=1.0.0"],
        "pose": ["mmcv-full>=2.0.0", "mmpose>=1.0.0"],
        "dev": ["pytest>=7.0", "black", "isort", "flake8"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
