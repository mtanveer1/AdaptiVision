import torch
import numpy as np
from torchvision import transforms
from torchvision.transforms import (
    RandomResizedCrop,
    RandomHorizontalFlip,
    ColorJitter,
    ToTensor,
    Normalize,
    Compose,
    CenterCrop,
    Resize,
)

try:
    from timm.data.auto_augment import rand_augment_transform
    from timm.data.random_erasing import RandomErasing
    HAS_TIMM = True
except ImportError:
    HAS_TIMM = False


IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD  = (0.229, 0.224, 0.225)

def build_train_transform(
    img_size: int = 224,
    use_rand_augment: bool = True,
    rand_augment_config: str = "rand-m9-mstd0.5-inc1",
    random_erasing_prob: float = 0.25,
    interpolation=transforms.InterpolationMode.BICUBIC,
) -> Compose:

    aug_list = [
        RandomResizedCrop(img_size, scale=(0.08, 1.0), interpolation=interpolation),
        RandomHorizontalFlip(),
    ]

    if use_rand_augment and HAS_TIMM:
        aug_list.append(rand_augment_transform(rand_augment_config, {}))

    aug_list += [
        ToTensor(),
        Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD),
    ]

    if random_erasing_prob > 0.0 and HAS_TIMM:
        aug_list.append(
            RandomErasing(
                probability=random_erasing_prob,
                mode="pixel",
                max_count=1,
            )
        )

    return Compose(aug_list)


def build_eval_transform(
    img_size: int = 224,
    crop_pct: float = 0.875,
    interpolation=transforms.InterpolationMode.BICUBIC,
) -> Compose:

    scale_size = int(img_size / crop_pct)
    return Compose([
        Resize(scale_size, interpolation=interpolation),
        CenterCrop(img_size),
        ToTensor(),
        Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD),
    ])

class MixupCutmix:

    def __init__(
        self,
        mixup_alpha: float = 0.8,
        cutmix_alpha: float = 1.0,
        prob: float = 1.0,
        num_classes: int = 1000,
    ):
        self.mixup_alpha  = mixup_alpha
        self.cutmix_alpha = cutmix_alpha
        self.prob         = prob
        self.num_classes  = num_classes

    def _one_hot(self, labels: torch.Tensor) -> torch.Tensor:
        return torch.zeros(
            labels.size(0), self.num_classes, device=labels.device
        ).scatter_(1, labels.unsqueeze(1), 1.0)

    def _cutmix_bbox(self, H: int, W: int, lam: float):
        cut_rat = np.sqrt(1.0 - lam)
        cut_h = int(H * cut_rat)
        cut_w = int(W * cut_rat)
        cy = np.random.randint(H)
        cx = np.random.randint(W)
        y1 = max(cy - cut_h // 2, 0)
        x1 = max(cx - cut_w // 2, 0)
        y2 = min(cy + cut_h // 2, H)
        x2 = min(cx + cut_w // 2, W)
        return y1, x1, y2, x2

    def __call__(
        self, images: torch.Tensor, labels: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if np.random.rand() > self.prob:
            return images, self._one_hot(labels)

        use_cutmix = (
            self.cutmix_alpha > 0.0
            and (self.mixup_alpha <= 0.0 or np.random.rand() < 0.5)
        )

        B, C, H, W = images.shape
        idx = torch.randperm(B, device=images.device)
        label_a = self._one_hot(labels)
        label_b = label_a[idx]

        if use_cutmix and self.cutmix_alpha > 0.0:
            lam = np.random.beta(self.cutmix_alpha, self.cutmix_alpha)
            y1, x1, y2, x2 = self._cutmix_bbox(H, W, lam)
            images = images.clone()
            images[:, :, y1:y2, x1:x2] = images[idx, :, y1:y2, x1:x2]
            lam = 1.0 - (y2 - y1) * (x2 - x1) / (H * W)
        else:
            lam = np.random.beta(self.mixup_alpha, self.mixup_alpha)
            images = lam * images + (1.0 - lam) * images[idx]

        mixed_labels = lam * label_a + (1.0 - lam) * label_b
        return images, mixed_labels
