import math
import time
from collections import defaultdict, deque
from typing import Optional

import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import LambdaLR

def build_optimizer(
    model: nn.Module,
    lr: float = 1e-3,
    weight_decay: float = 5e-2,
    betas: tuple = (0.9, 0.999),
    no_decay_keywords: tuple = ("bias", "norm", "pos_embed", "centroids"),
) -> AdamW:
    
    decay_params, no_decay_params = [], []
    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if any(kw in name for kw in no_decay_keywords):
            no_decay_params.append(param)
        else:
            decay_params.append(param)

    param_groups = [
        {"params": decay_params,    "weight_decay": weight_decay},
        {"params": no_decay_params, "weight_decay": 0.0},
    ]
    return AdamW(param_groups, lr=lr, betas=betas)

def build_cosine_scheduler(
    optimizer: torch.optim.Optimizer,
    total_steps: int,
    warmup_steps: int,
    min_lr_ratio: float = 1e-2,
) -> LambdaLR:
    
    def lr_lambda(step: int) -> float:
        if step < warmup_steps:
            return float(step) / max(1, warmup_steps)
        progress = float(step - warmup_steps) / max(1, total_steps - warmup_steps)
        cosine_decay = 0.5 * (1.0 + math.cos(math.pi * progress))
        return max(min_lr_ratio, cosine_decay)

    return LambdaLR(optimizer, lr_lambda)

class AverageMeter:
  
    def __init__(self, window: int = 20):
        self.deque = deque(maxlen=window)
        self.total = 0.0
        self.count = 0

    def update(self, value: float, n: int = 1):
        self.deque.append(value)
        self.total += value * n
        self.count += n

    @property
    def avg(self) -> float:
        return self.total / max(1, self.count)

    @property
    def global_avg(self) -> float:
        return self.total / max(1, self.count)

    @property
    def median(self) -> float:
        d = sorted(self.deque)
        return d[len(d) // 2] if d else 0.0


class MetricLogger:
    
    def __init__(self, delimiter: str = "  "):
        self.meters = defaultdict(AverageMeter)
        self.delimiter = delimiter

    def update(self, **kwargs):
        for k, v in kwargs.items():
            if isinstance(v, torch.Tensor):
                v = v.item()
            self.meters[k].update(v)

    def __str__(self) -> str:
        parts = []
        for name, meter in self.meters.items():
            parts.append(f"{name}: {meter.median:.4f} ({meter.global_avg:.4f})")
        return self.delimiter.join(parts)

    def log_every(self, iterable, print_freq: int, header: str = ""):
        start = time.time()
        end = time.time()
        for i, obj in enumerate(iterable):
            yield obj
            self.meters["iter_time"].update(time.time() - end)
            end = time.time()
            if i % print_freq == 0 or i == len(iterable) - 1:
                elapsed = time.time() - start
                print(f"{header}  [{i}/{len(iterable)}]  {self}  "
                      f"time: {elapsed:.1f}s")



@torch.no_grad()
def accuracy(output: torch.Tensor, target: torch.Tensor, topk: tuple = (1, 5)):
    
    maxk = max(topk)
    batch_size = target.size(0)

    _, pred = output.topk(maxk, dim=1, largest=True, sorted=True)
    pred = pred.t()
    correct = pred.eq(target.view(1, -1).expand_as(pred))

    results = []
    for k in topk:
        correct_k = correct[:k].reshape(-1).float().sum(0, keepdim=True)
        results.append(correct_k.mul_(100.0 / batch_size).item())
    return results

def clip_gradients(model: nn.Module, max_norm: float = 1.0):
    return nn.utils.clip_grad_norm_(model.parameters(), max_norm)
