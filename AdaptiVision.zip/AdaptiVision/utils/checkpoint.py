import os
import shutil
import torch
import torch.nn as nn
from pathlib import Path


def save_checkpoint(
    state: dict,
    checkpoint_dir: str,
    epoch: int,
    is_best: bool = False,
    keep_last: int = 3,
) -> str:

    os.makedirs(checkpoint_dir, exist_ok=True)
    filename = os.path.join(checkpoint_dir, f"epoch_{epoch:04d}.pth")
    torch.save(state, filename)

    if is_best:
        best_path = os.path.join(checkpoint_dir, "best.pth")
        shutil.copy(filename, best_path)
        print(f"  New best checkpoint saved → {best_path}")

    # Prune old checkpoints
    if keep_last > 0:
        ckpts = sorted(Path(checkpoint_dir).glob("epoch_*.pth"))
        for old in ckpts[:-keep_last]:
            old.unlink()

    return filename


def load_checkpoint(
    path: str,
    model: nn.Module,
    optimizer=None,
    scheduler=None,
    device: str = "cpu",
) -> dict:
    
    ckpt = torch.load(path, map_location=device)

    state_dict = ckpt.get("model", ckpt)
    model.load_state_dict(state_dict, strict=True)
    print(f"  Loaded model weights from '{path}'")

    meta = {
        "epoch": ckpt.get("epoch", -1),
        "best_acc1": ckpt.get("best_acc1", 0.0),
    }

    if optimizer is not None and "optimizer" in ckpt:
        optimizer.load_state_dict(ckpt["optimizer"])
        print("  Restored optimizer state.")

    if scheduler is not None and "scheduler" in ckpt:
        scheduler.load_state_dict(ckpt["scheduler"])
        print("  Restored scheduler state.")

    return meta


def load_pretrained_backbone(
    model: nn.Module,
    pretrained_path: str,
    device: str = "cpu",
    strict: bool = False,
) -> None:
    
    ckpt = torch.load(pretrained_path, map_location=device)
    state_dict = ckpt.get("model", ckpt)

    filtered = {
        k: v for k, v in state_dict.items()
        if not k.startswith("head.")
    }

    missing, unexpected = model.load_state_dict(filtered, strict=strict)
    print(f"  Loaded pretrained backbone from '{pretrained_path}'")
    if missing:
        print(f"  Missing keys ({len(missing)}): {missing[:5]}{'...' if len(missing) > 5 else ''}")
    if unexpected:
        print(f"  Unexpected keys ({len(unexpected)}): {unexpected[:5]}{'...' if len(unexpected) > 5 else ''}")
