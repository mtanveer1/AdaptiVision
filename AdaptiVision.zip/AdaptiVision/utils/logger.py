
import sys
import time
import datetime
import logging
from collections import deque, defaultdict
from typing import Optional

import torch


def get_logger(name: str = "adaptivision", log_file: Optional[str] = None) -> logging.Logger:
   
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False

    fmt = logging.Formatter(
        "[%(asctime)s] %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    if not logger.handlers:
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        logger.addHandler(sh)

    if log_file:
        fh = logging.FileHandler(log_file)
        fh.setFormatter(fmt)
        logger.addHandler(fh)

    return logger


class SmoothedValue:
   
    def __init__(self, window_size: int = 20, fmt: str = "{median:.4f} ({global_avg:.4f})"):
        self.deque = deque(maxlen=window_size)
        self.total = 0.0
        self.count = 0
        self.fmt = fmt

    def update(self, value: float, n: int = 1) -> None:
        self.deque.append(value)
        self.total += value * n
        self.count += n

    @property
    def median(self) -> float:
        d = torch.tensor(list(self.deque))
        return d.median().item()

    @property
    def avg(self) -> float:
        d = torch.tensor(list(self.deque), dtype=torch.float32)
        return d.mean().item()

    @property
    def global_avg(self) -> float:
        return self.total / max(self.count, 1)

    def __str__(self) -> str:
        return self.fmt.format(
            median=self.median,
            avg=self.avg,
            global_avg=self.global_avg,
            value=self.deque[-1] if self.deque else 0.0,
        )


class MetricLogger:
   
    def __init__(self, delimiter: str = "  "):
        self.meters = defaultdict(SmoothedValue)
        self.delimiter = delimiter

    def update(self, **kwargs) -> None:
        for k, v in kwargs.items():
            if isinstance(v, torch.Tensor):
                v = v.item()
            self.meters[k].update(v)

    def __getattr__(self, attr: str) -> SmoothedValue:
        if attr in self.meters:
            return self.meters[attr]
        raise AttributeError(f"MetricLogger has no attribute '{attr}'")

    def __str__(self) -> str:
        parts = [f"{k}: {v}" for k, v in self.meters.items()]
        return self.delimiter.join(parts)

    def log_every(self, iterable, print_freq: int = 50, header: str = ""):
     
        i = 0
        start = time.time()
        end = time.time()
        iter_time = SmoothedValue(fmt="{avg:.3f}")
        data_time = SmoothedValue(fmt="{avg:.3f}")

        for obj in iterable:
            data_time.update(time.time() - end)
            yield obj
            iter_time.update(time.time() - end)

            if i % print_freq == 0:
                eta = datetime.timedelta(seconds=int(iter_time.avg * (len(iterable) - i)))
                print(
                    f"{header}  [{i}/{len(iterable)}]"
                    f"  eta: {eta}"
                    f"  iter: {iter_time}"
                    f"  data: {data_time}"
                    f"  {self}"
                )
                sys.stdout.flush()

            i += 1
            end = time.time()

        total = time.time() - start
        print(f"{header}  Total time: {datetime.timedelta(seconds=int(total))}"
              f"  ({total / len(iterable):.3f} s/it)")
