import argparse
import sys
import time
import yaml
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from torchvision.datasets import ImageFolder

sys.path.insert(0, str(Path(__file__).parent.parent))

from models import AdaptiVision
from utils import accuracy, build_eval_transform


def parse_args():
    p = argparse.ArgumentParser("AdaptiVision Evaluation")
    p.add_argument("--config",     required=True)
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--device",     default="cuda")
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--throughput", action="store_true",
                   help="Benchmark images/sec.")
    return p.parse_args()


@torch.no_grad()
def benchmark_throughput(model, img_size: int, device, batch_size: int = 64,
                         n_warmup: int = 50, n_steps: int = 200) -> float:
    model.eval()
    dummy = torch.randn(batch_size, 3, img_size, img_size, device=device)

    for _ in range(n_warmup):
        model(dummy)

    if device.type == "cuda":
        torch.cuda.synchronize()

    t0 = time.perf_counter()
    for _ in range(n_steps):
        model(dummy)

    if device.type == "cuda":
        torch.cuda.synchronize()

    elapsed = time.perf_counter() - t0
    throughput = (n_steps * batch_size) / elapsed
    return throughput


def main():
    args = parse_args()
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    model_cfg = cfg["model"]
    model = AdaptiVision(
        img_size=model_cfg["img_size"],
        patch_size=model_cfg["patch_size"],
        num_classes=model_cfg["num_classes"],
        embed_dims=model_cfg["embed_dims"],
        num_heads=model_cfg["num_heads"],
        num_blocks=model_cfg["num_blocks"],
        cluster_ks=model_cfg["cluster_ks"],
        mlp_ratio=model_cfg["mlp_ratio"],
        drop=0.0,   
        attn_drop=0.0,
    ).to(device)

    ckpt = torch.load(args.checkpoint, map_location=device)
    state = ckpt["model"] if "model" in ckpt else ckpt
    model.load_state_dict(state)
    model.eval()

    # ── Accuracy ──────────────────────────────────────────────────────────
    val_ds = ImageFolder(
        cfg["data"]["val_dir"],
        transform=build_eval_transform(img_size=model_cfg["img_size"]),
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=cfg["data"]["num_workers"],
        pin_memory=True,
    )

    acc1_list, acc5_list = [], []
    for images, labels in val_loader:
        images = images.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)
        logits = model(images)
        a1, a5 = accuracy(logits, labels, topk=(1, 5))
        acc1_list.append(a1)
        acc5_list.append(a5)

    avg1 = sum(acc1_list) / len(acc1_list)
    avg5 = sum(acc5_list) / len(acc5_list)
    print(f"\nResults on ImageNet-1K:")
    print(f"  Top-1 Accuracy: {avg1:.2f}%")
    print(f"  Top-5 Accuracy: {avg5:.2f}%")

    if args.throughput:
        tp = benchmark_throughput(model, model_cfg["img_size"], device)
        print(f"  Throughput:     {tp:.1f} images/s")


if __name__ == "__main__":
    main()
