import argparse
import os
import sys
import yaml
import time
from pathlib import Path

import torch
import torch.nn as nn
from torch.cuda.amp import GradScaler, autocast
from torch.utils.data import DataLoader
from torchvision.datasets import ImageFolder
from torch.utils.tensorboard import SummaryWriter

sys.path.insert(0, str(Path(__file__).parent.parent))

from models import AdaptiVision
from modules import AdaptiVisionLoss
from utils import (
    build_optimizer,
    build_cosine_scheduler,
    MetricLogger,
    accuracy,
    clip_gradients,
    build_train_transform,
    build_eval_transform,
    MixupCutmix,
)


def parse_args():
    p = argparse.ArgumentParser("AdaptiVision ImageNet Training")
    p.add_argument("--config",  default='./configs/imagenet_light.yaml',  help="Path to YAML config.")
    p.add_argument("--resume",  default=None,   help="Checkpoint to resume from.")
    p.add_argument("--device",  default="cuda", help="Device: cuda / cpu.")
    p.add_argument("--local_rank", type=int, default=0)
    return p.parse_args()


def train_one_epoch(
    model, criterion, loader, optimizer, scheduler, scaler,
    device, epoch, cfg, writer=None, mixup=None,
):
    model.train()
    logger = MetricLogger()
    header = f"[Train] Epoch {epoch}"

    for step, (images, labels) in enumerate(
        logger.log_every(loader, cfg["logging"]["print_freq"], header)
    ):
        images = images.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        if mixup is not None:
            images, soft_labels = mixup(images, labels)

        with autocast(enabled=cfg["training"]["amp"]):
            logits, aux = model(images, return_aux=True)

            if mixup is not None:

                log_probs = torch.log_softmax(logits.float(), dim=-1).clamp(min=-100.0)
                l_ce = -(soft_labels.float() * log_probs).sum(dim=-1).mean()

                l_cluster = criterion.cluster_loss(
                    aux["stage_inputs"], aux["centroids"], aux["assign_mats"]
                )
                l_recon = criterion.recon_loss(
                    aux["stage_inputs"], aux["stage_outputs"], aux["assign_mats"]
                )
                loss = (l_ce
                        + criterion.lambda_cluster * l_cluster
                        + criterion.lambda_recon * l_recon)
                loss_dict = {"total": loss, "ce": l_ce,
                             "cluster": l_cluster, "recon": l_recon}
            else:
                loss_dict = criterion(
                    logits, labels,
                    aux["stage_inputs"], aux["stage_outputs"],
                    aux["centroids"],    aux["assign_mats"],
                )
                loss = loss_dict["total"]

        if not torch.isfinite(loss):
            print(f"[WARNING] Non-finite loss {loss.item():.4f} at step {step}, skipping update")
            optimizer.zero_grad()
            scaler.update()   
            continue

        optimizer.zero_grad()
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)

        for p in model.parameters():
            if p.grad is not None and not torch.isfinite(p.grad).all():
                p.grad.zero_()

        clip_gradients(model, cfg["training"]["clip_grad"])
        scaler.step(optimizer)
        scaler.update()
        scheduler.step()

        logger.update(
            loss=loss_dict["total"],
            loss_ce=loss_dict["ce"],
            loss_cluster=loss_dict["cluster"],
            loss_recon=loss_dict["recon"],
            lr=scheduler.get_last_lr()[0],
        )

    return logger


@torch.no_grad()
def evaluate(model, loader, device):
    model.eval()
    acc1_meter, acc5_meter = [], []

    for images, labels in loader:
        images = images.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        logits = model(images)
        a1, a5 = accuracy(logits, labels, topk=(1, 5))
        acc1_meter.append(a1)
        acc5_meter.append(a5)

    avg1 = sum(acc1_meter) / len(acc1_meter)
    avg5 = sum(acc5_meter) / len(acc5_meter)
    print(f"  Validation  Top-1: {avg1:.2f}%  Top-5: {avg5:.2f}%")
    return avg1, avg5


def main():
    args = parse_args()

    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    os.makedirs(cfg["logging"]["checkpoint_dir"], exist_ok=True)

    model_cfg = cfg["model"]
    model = AdaptiVision(
        img_size=model_cfg["img_size"],
        patch_size=model_cfg["patch_size"],
        num_classes=model_cfg["num_classes"],
        embed_dims=model_cfg["embed_dims"],
        num_heads=model_cfg["num_heads"],
        num_blocks=model_cfg["num_blocks"],
        cluster_ks=model_cfg["cluster_ks"],
        mlp_ratio=model_cfg["mlp_ratio"],
        drop=model_cfg["drop"],
        attn_drop=model_cfg["attn_drop"],
        gate_ratio=model_cfg["gate_ratio"],
    ).to(device)

    criterion = AdaptiVisionLoss(
        dims=model_cfg["embed_dims"][:3],
        num_stages=3,
        lambda_cluster=cfg["loss"]["lambda_cluster"],
        lambda_recon=cfg["loss"]["lambda_recon"],
        label_smoothing=cfg["loss"]["label_smoothing"],
    ).to(device)

    train_ds = ImageFolder(
        cfg["data"]["train_dir"],
        transform=build_train_transform(
            img_size=model_cfg["img_size"],
            use_rand_augment=cfg["data"]["rand_augment"],
            rand_augment_config=cfg["data"]["rand_augment_config"],
            random_erasing_prob=cfg["data"]["random_erasing_prob"],
        ),
    )
    val_ds = ImageFolder(
        cfg["data"]["val_dir"],
        transform=build_eval_transform(img_size=model_cfg["img_size"]),
    )

    train_loader = DataLoader(
        train_ds,
        batch_size=cfg["training"]["batch_size"],
        shuffle=True,
        num_workers=cfg["data"]["num_workers"],
        pin_memory=cfg["data"]["pin_memory"],
        drop_last=True,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=cfg["training"]["batch_size"] * 2,
        shuffle=False,
        num_workers=cfg["data"]["num_workers"],
        pin_memory=cfg["data"]["pin_memory"],
    )

    # ── Optimizer & scheduler ─────────────────────────────────────────────
    optimizer = build_optimizer(
        model,
        lr=cfg["optimizer"]["lr"],
        weight_decay=cfg["optimizer"]["weight_decay"],
    )

    steps_per_epoch = len(train_loader)
    total_steps = cfg["training"]["epochs"] * steps_per_epoch
    warmup_steps = cfg["scheduler"]["warmup_epochs"] * steps_per_epoch

    scheduler = build_cosine_scheduler(
        optimizer,
        total_steps=total_steps,
        warmup_steps=warmup_steps,
        min_lr_ratio=cfg["scheduler"]["min_lr_ratio"],
    )

    scaler = GradScaler(enabled=cfg["training"]["amp"])

    mixup = MixupCutmix(
        mixup_alpha=cfg["data"]["mixup_alpha"],
        cutmix_alpha=cfg["data"]["cutmix_alpha"],
        prob=cfg["data"]["mixup_prob"],
        num_classes=model_cfg["num_classes"],
    )

    start_epoch = 0
    best_acc1 = 0.0

    if args.resume:
        ckpt = torch.load(args.resume, map_location=device)
        model.load_state_dict(ckpt["model"])
        optimizer.load_state_dict(ckpt["optimizer"])
        scheduler.load_state_dict(ckpt["scheduler"])
        start_epoch = ckpt["epoch"] + 1
        best_acc1 = ckpt.get("best_acc1", 0.0)
        print(f"Resumed from epoch {start_epoch}, best_acc1={best_acc1:.2f}%")

    writer = None
    if cfg["logging"].get("tensorboard"):
        writer = SummaryWriter(cfg["logging"]["checkpoint_dir"])

    for epoch in range(start_epoch, cfg["training"]["epochs"]):
        train_log = train_one_epoch(
            model, criterion, train_loader, optimizer, scheduler, scaler,
            device, epoch, cfg, writer, mixup,
        )

        acc1, acc5 = evaluate(model, val_loader, device)

        if writer:
            writer.add_scalar("val/top1", acc1, epoch)
            writer.add_scalar("val/top5", acc5, epoch)

        is_best = acc1 > best_acc1
        best_acc1 = max(acc1, best_acc1)

        ckpt_path = os.path.join(
            cfg["logging"]["checkpoint_dir"], f"epoch_{epoch:03d}.pth"
        )
        if epoch % cfg["logging"]["checkpoint_freq"] == 0 or is_best:
            torch.save(
                {
                    "epoch": epoch,
                    "model": model.state_dict(),
                    "optimizer": optimizer.state_dict(),
                    "scheduler": scheduler.state_dict(),
                    "best_acc1": best_acc1,
                },
                ckpt_path,
            )
            if is_best:
                import shutil
                shutil.copy(
                    ckpt_path,
                    os.path.join(cfg["logging"]["checkpoint_dir"], "best.pth"),
                )
                print(f"  ✓ New best: {best_acc1:.2f}%")

    print(f"\nTraining complete. Best Top-1: {best_acc1:.2f}%")
    if writer:
        writer.close()


if __name__ == "__main__":
    main()
