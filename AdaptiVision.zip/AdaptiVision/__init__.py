"""
AdaptiVision — A Flexible and Efficient Vision Transformer for Adaptive Token Pruning
"""

from models.adaptivision import (
    AdaptiVision,
    adaptivision_light,
    adaptivision_medium,
    adaptivision_large,
)
from modules import (
    CoordinateAwareDynamicTokenClustering,
    AdaptiveFocusAttention,
    MixFFN,
    AdaptiVisionLoss,
)

__version__ = "1.0.0"

__all__ = [
    "AdaptiVision",
    "adaptivision_light",
    "adaptivision_medium",
    "adaptivision_large",
    "CoordinateAwareDynamicTokenClustering",
    "AdaptiveFocusAttention",
    "MixFFN",
    "AdaptiVisionLoss",
]
