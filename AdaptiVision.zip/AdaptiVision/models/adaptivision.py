from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F

from modules.ca_dtc import CoordinateAwareDynamicTokenClustering
from modules.afa   import AdaptiveFocusAttention
from modules.mix_ffn import MixFFN

class AdaptiVisionBlock(nn.Module):
    def __init__(self, dim, num_heads, afa_reduction=4, ffn_expansion=4,
                 attn_drop=0.0, proj_drop=0.0, drop_path=0.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn  = AdaptiveFocusAttention(
            dim=dim, num_heads=num_heads, reduction=afa_reduction,
            attn_drop=attn_drop, proj_drop=proj_drop)
        self.ffn   = MixFFN(dim=dim, expansion=ffn_expansion, drop=proj_drop)
        self.dp    = drop_path

    def _drop_path(self, x, res):
        if self.dp > 0 and self.training:
            keep = torch.bernoulli(
                torch.full((x.shape[0], 1, 1), 1 - self.dp, device=x.device))
            return res + x * keep / (1 - self.dp)
        return res + x

    def forward(self, x):
        x = self._drop_path(self.attn(self.norm1(x)), x)
        x = self.ffn(x)
        return x


class PatchEmbed(nn.Module):
    def __init__(self, img_size=224, patch_size=4, in_chans=3, embed_dim=96):
        super().__init__()
        self.patch_size = patch_size
        num_patches = (img_size // patch_size) ** 2
        self.num_patches = num_patches
        self.proj = nn.Conv2d(in_chans, embed_dim,
                              kernel_size=patch_size, stride=patch_size)
        self.norm = nn.LayerNorm(embed_dim)
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches, embed_dim))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)

    def forward(self, x):
        x = self.proj(x)                     
        B, D, H, W = x.shape
        x = x.flatten(2).transpose(1, 2)       
        x = self.norm(x)
        pos = self.pos_embed.expand(B, -1, -1)
        return x + pos, pos


class StageTransition(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.proj = nn.Linear(in_dim, out_dim) if in_dim != out_dim else nn.Identity()
        self.norm = nn.LayerNorm(out_dim)

    def forward(self, x):
        return self.norm(self.proj(x))


class AdaptiVisionStage(nn.Module):

    def __init__(self, ca_dtc, transition, pos_proj, blocks):
        super().__init__()
        self.ca_dtc     = ca_dtc       
        self.transition = transition   
        self.pos_proj   = pos_proj     
        self.blocks     = nn.ModuleList(blocks)

    def forward(self, tokens, pos, collect_aux=False):
        A = S_in = S_out = None
        if self.ca_dtc is not None:
            S_in = tokens
            tokens, pos_cluster, A = self.ca_dtc(tokens, pos)
            S_out  = tokens                     
            tokens = self.transition(tokens)
            pos    = self.pos_proj(pos_cluster)
        for blk in self.blocks:
            tokens = blk(tokens)
        if collect_aux:
            return tokens, pos, A, S_in, S_out
        return tokens, pos

class AdaptiVision(nn.Module):
    

    def __init__(
        self,
        img_size=224, patch_size=4, in_chans=3, num_classes=1000,
    
        embed_dims=(96, 192, 384, 768),
        num_heads=(3, 6, 12, 24),
        num_blocks=(3, 5, 9, 3),
        cluster_ks=(64, 16, 4),
        mlp_ratio=4,
        drop=0.0,
        attn_drop=0.0,
        gate_ratio=4,
        drop_path_rate=0.1,
        tau=0.07,
  
        dims=None, depths=None, cluster_K=None,
        ffn_expansion=None, drop_rate=None, afa_reduction=None,
    ):
        super().__init__()
 
        if dims        is not None: embed_dims  = dims
        if depths      is not None: num_blocks  = depths
        if cluster_K   is not None: cluster_ks  = cluster_K
        if ffn_expansion is not None: mlp_ratio = ffn_expansion
        if drop_rate   is not None: drop        = drop_rate
        if afa_reduction is not None: gate_ratio = afa_reduction

        assert len(embed_dims) == 4 == len(num_blocks) == len(num_heads)
        assert len(cluster_ks) == 3

        dims      = embed_dims
        depths    = num_blocks
        cluster_K = cluster_ks
        ffn_expansion = mlp_ratio
        drop_rate     = drop
        afa_reduction = gate_ratio

        self.num_classes = num_classes
        self.embed_dims  = list(dims)   

        self.patch_embed = PatchEmbed(img_size, patch_size, in_chans, dims[0])

        total = sum(depths)
        dpr   = [x.item() for x in torch.linspace(0, drop_path_rate, total)]
        blk_i = 0

        stages = []
        for s in range(4):
            if s == 0:
                ca_dtc     = None
                transition = nn.Identity()
                pos_proj   = nn.Identity()
            else:
                in_d, out_d = dims[s - 1], dims[s]
                ca_dtc = CoordinateAwareDynamicTokenClustering(
                    dim=in_d, num_clusters=cluster_K[s - 1], tau=tau)
                transition = StageTransition(in_d, out_d)
                pos_proj   = (nn.Linear(in_d, out_d)
                              if in_d != out_d else nn.Identity())

            blocks = [
                AdaptiVisionBlock(
                    dim=dims[s], num_heads=num_heads[s],
                    afa_reduction=afa_reduction, ffn_expansion=ffn_expansion,
                    attn_drop=attn_drop, proj_drop=drop_rate,
                    drop_path=dpr[blk_i + j])
                for j in range(depths[s])
            ]
            stages.append(AdaptiVisionStage(ca_dtc, transition, pos_proj, blocks))
            blk_i += depths[s]

        self.stage1, self.stage2, self.stage3, self.stage4 = stages

        self.norm = nn.LayerNorm(dims[-1])
        self.head = nn.Linear(dims[-1], num_classes) if num_classes > 0 else nn.Identity()
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.LayerNorm):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)


    def forward_features(self, x):
        tokens, pos = self.patch_embed(x)
        for stage in [self.stage1, self.stage2, self.stage3, self.stage4]:
            tokens, pos = stage(tokens, pos, collect_aux=False)
        return self.norm(tokens.mean(dim=1))

    def forward(self, x, return_aux=False):
        
        if not return_aux:
            feat = self.forward_features(x)
            return self.head(feat)

        tokens, pos = self.patch_embed(x)
        stage_inputs, stage_outputs, centroids, assign_mats = [], [], [], []

        for s, stage in enumerate([self.stage1, self.stage2,
                                    self.stage3, self.stage4]):
            tokens, pos, A, S_in, S_out = stage(tokens, pos, collect_aux=True)
            if A is not None:                      
                stage_inputs.append(S_in)
                stage_outputs.append(S_out)
                centroids.append(stage.ca_dtc.centroids)
                assign_mats.append(A)

        feat   = self.norm(tokens.mean(dim=1))
        logits = self.head(feat)
        aux = {
            "stage_inputs" : stage_inputs,
            "stage_outputs": stage_outputs,
            "centroids"    : centroids,
            "assign_mats"  : assign_mats,
        }
        return logits, aux

    @classmethod
    def from_pretrained(cls, variant: str, num_classes: int = 1000,
                        checkpoint_path: str | None = None, **kwargs):
        
        builders = {
            "adaptivision-light":  adaptivision_light,
            "adaptivision-medium": adaptivision_medium,
            "adaptivision-large":  adaptivision_large,
        }
        if variant not in builders:
            raise ValueError(f"Unknown variant '{variant}'. "
                             f"Choose from: {list(builders)}")
        model = builders[variant](num_classes=num_classes, **kwargs)
        if checkpoint_path:
            ckpt  = torch.load(checkpoint_path, map_location="cpu")
            state = ckpt.get("model", ckpt)
            model.load_state_dict(state, strict=False)
        return model


def adaptivision_light(**kwargs) -> AdaptiVision:
    return AdaptiVision(
        embed_dims=(64, 128, 256, 512), num_blocks=(2, 2, 4, 2),
        num_heads=(2, 4, 8, 16),        cluster_ks=(128, 32, 8), **kwargs)


def adaptivision_medium(**kwargs) -> AdaptiVision:
    return AdaptiVision(
        embed_dims=(64, 128, 320, 512), num_blocks=(3, 4, 6, 3),
        num_heads=(1, 2, 5, 8),         cluster_ks=(64, 16, 4), **kwargs)


def adaptivision_large(**kwargs) -> AdaptiVision:
    return AdaptiVision(
        embed_dims=(96, 192, 384, 768), num_blocks=(3, 5, 9, 3),
        num_heads=(3, 6, 12, 24),       cluster_ks=(64, 16, 4), **kwargs)
