import argparse
import os
import sys
import random
import yaml
import numpy as np
import torch
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def parse_args():
    p = argparse.ArgumentParser("AdaptiVision — Unified Training Entry Point")
    p.add_argument("--config",    required=True,  help="Path to YAML config file.")
    p.add_argument("--resume",    default=None,   help="Checkpoint path to resume from.")
    p.add_argument("--device",    default="cuda", help="Compute device: cuda or cpu.")
    p.add_argument("--seed",      type=int, default=42, help="Global random seed.")
    p.add_argument("--eval-only", action="store_true",  help="Run evaluation only.")
    p.add_argument("--local_rank", type=int, default=0, help="Local rank for DDP.")
    return p.parse_args()


def main():
    args = parse_args()
    set_seed(args.seed)

    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    task = cfg.get("data", {}).get("task", "classification")

    if task == "classification":
        from scripts.train_imagenet import main as train_main
        # Inject parsed CLI args into sys.argv for the sub-script
        sys.argv = [
            "train_imagenet.py",
            f"--config={args.config}",
            f"--device={args.device}",
        ]
        if args.resume:
            sys.argv.append(f"--resume={args.resume}")
        train_main()

    elif task == "segmentation":
        # Delegates to mmsegmentation train pipeline
        try:
            from mmseg.apis import train_segmentor
        except ImportError:
            print("[ERROR] mmsegmentation not installed. Run: pip install mmsegmentation")
            sys.exit(1)
        print("Segmentation training: use mmseg tools/train.py with AdaptiVision backbone.")
        print(f"  Config: {args.config}")

    elif task == "pose":
        # Delegates to mmpose train pipeline
        try:
            from mmpose.apis import train_model
        except ImportError:
            print("[ERROR] mmpose not installed. Run: pip install mmpose")
            sys.exit(1)
        print("Pose training: use mmpose tools/train.py with AdaptiVision backbone.")
        print(f"  Config: {args.config}")

    else:
        raise ValueError(f"Unknown task '{task}'. Expected: classification, segmentation, pose.")


if __name__ == "__main__":
    main()
