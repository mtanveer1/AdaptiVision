import argparse
import sys
import time
import yaml
import torch
import torch.nn.functional as F
from pathlib import Path
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from models import AdaptiVision, adaptivision_light, adaptivision_medium, adaptivision_large
from data import build_loader


VARIANT_MAP = {
    "adaptivision-light":  adaptivision_light,
    "adaptivision-medium": adaptivision_medium,
    "adaptivision-large":  adaptivision_large,
}


def parse_args():
    p = argparse.ArgumentParser("AdaptiVision Evaluation")
    p.add_argument("--config",     required=True,  help="Path to YAML config.")
    p.add_argument("--checkpoint", required=True,  help="Path to model checkpoint (.pth).")
    p.add_argument("--device",     default="cuda", help="Compute device.")
    p.add_argument("--throughput", action="store_true", help="Benchmark throughput.")
    p.add_argument("--batch-size", type=int, default=None, help="Override batch size.")
    return p.parse_args()


@torch.no_grad()
def evaluate_classification(
    model: torch.nn.Module,
    loader: DataLoader,
    device: torch.device,
) -> dict:
    model.eval()
    correct1 = correct5 = total = 0

    for images, labels in loader:
        images = images.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)
        logits = model(images)

        # Top-1
        pred1 = logits.argmax(dim=1)
        correct1 += (pred1 == labels).sum().item()

        # Top-5
        top5 = logits.topk(5, dim=1).indices
        correct5 += sum(labels[i] in top5[i] for i in range(len(labels)))

        total += labels.size(0)

    return {
        "top1": 100.0 * correct1 / total,
        "top5": 100.0 * correct5 / total,
        "total_samples": total,
    }


@torch.no_grad()
def benchmark_throughput(
    model: torch.nn.Module,
    img_size: int,
    device: torch.device,
    batch_size: int = 64,
    warmup: int = 50,
    runs: int = 200,
) -> float:
    model.eval()
    dummy = torch.randn(batch_size, 3, img_size, img_size, device=device)

    # Warmup
    for _ in range(warmup):
        model(dummy)

    if device.type == "cuda":
        torch.cuda.synchronize()

    t0 = time.perf_counter()
    for _ in range(runs):
        model(dummy)
    if device.type == "cuda":
        torch.cuda.synchronize()
    elapsed = time.perf_counter() - t0

    return (runs * batch_size) / elapsed


def main():
    args = parse_args()
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    model_cfg = cfg["model"]
    if args.batch_size:
        cfg["training"]["batch_size"] = args.batch_size

    # Build model
    factory = VARIANT_MAP.get(model_cfg["name"])
    if factory is None:
        raise ValueError(f"Unknown model name '{model_cfg['name']}'. "
                         f"Choose from: {list(VARIANT_MAP)}")

    model = factory(
        img_size=model_cfg["img_size"],
        num_classes=model_cfg["num_classes"],
    ).to(device)

    # Load checkpoint
    ckpt = torch.load(args.checkpoint, map_location=device)
    state = ckpt.get("model", ckpt)
    model.load_state_dict(state)
    print(f"Loaded checkpoint from '{args.checkpoint}'")

    total_params = sum(p.numel() for p in model.parameters()) / 1e6
    print(f"Model params: {total_params:.1f}M")

    task = cfg.get("data", {}).get("task", "classification")

    if task == "classification":
        cfg["data"]["task"] = "classification"
        val_loader = build_loader(cfg, split="val")
        metrics = evaluate_classification(model, val_loader, device)
        print(f"\n{'='*40}")
        print(f"  Top-1 Accuracy : {metrics['top1']:.2f}%")
        print(f"  Top-5 Accuracy : {metrics['top5']:.2f}%")
        print(f"  Evaluated on   : {metrics['total_samples']:,} images")
        print(f"{'='*40}")

    if args.throughput:
        tput = benchmark_throughput(
            model, model_cfg["img_size"], device,
            batch_size=min(64, cfg["training"]["batch_size"])
        )
        print(f"\n  Throughput : {tput:.1f} images/sec")


if __name__ == "__main__":
    main()
