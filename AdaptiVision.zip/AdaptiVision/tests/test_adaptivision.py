import sys
import os
import math
import pytest
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@pytest.fixture(scope="module")
def device():
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


@pytest.fixture(scope="module")
def dummy_batch(device):
    return torch.randn(2, 3, 224, 224, device=device)


class TestCADTC:
    def setup_method(self):
        from modules.ca_dtc import CoordinateAwareDynamicTokenClustering
        self.CA_DTC = CoordinateAwareDynamicTokenClustering

    def test_output_shape(self, device):
        B, N, D, K = 2, 196, 64, 16
        m = self.CA_DTC(dim=D, num_clusters=K).to(device)
        z = torch.randn(B, N, D, device=device)
        p = torch.randn(B, N, D, device=device)
        s_out, p_cluster, A = m(z, p)
        assert s_out.shape    == (B, K, D)
        assert p_cluster.shape == (B, K, D)
        assert A.shape        == (B, N, K)

    def test_assignment_sums_to_one(self, device):
        B, N, D, K = 2, 64, 32, 8
        m = self.CA_DTC(dim=D, num_clusters=K).to(device)
        z = torch.randn(B, N, D, device=device)
        p = torch.randn(B, N, D, device=device)
        _, _, A = m(z, p)
        assert torch.allclose(A.sum(dim=-1), torch.ones(B, N, device=device), atol=1e-5)

    def test_differentiable(self, device):
        B, N, D, K = 2, 32, 16, 4
        m = self.CA_DTC(dim=D, num_clusters=K).to(device)
        z = torch.randn(B, N, D, device=device, requires_grad=True)
        p = torch.randn(B, N, D, device=device, requires_grad=True)
        s_out, _, _ = m(z, p)
        s_out.sum().backward()
        assert z.grad is not None
        assert p.grad is not None

    def test_k_less_than_n(self, device):
        for K in [4, 8, 16]:
            m = self.CA_DTC(dim=64, num_clusters=K).to(device)
            z = torch.randn(2, 196, 64, device=device)
            p = torch.randn(2, 196, 64, device=device)
            s_out, _, _ = m(z, p)
            assert s_out.shape[1] == K


class TestAFA:
    def setup_method(self):
        from modules.afa import AdaptiveFocusAttention
        self.AFA = AdaptiveFocusAttention

    def test_output_shape(self, device):
        B, K, D = 2, 16, 64
        m = self.AFA(dim=D, num_heads=4).to(device)
        x = torch.randn(B, K, D, device=device)
        out = m(x)
        assert out.shape == (B, K, D)

    def test_gate_values_in_range(self, device):
        B, K, D = 2, 16, 64
        m = self.AFA(dim=D, num_heads=4).to(device)
        gates = []
        m.gate.register_forward_hook(lambda mod, inp, out: gates.append(out))
        x = torch.randn(B, K, D, device=device)
        m(x)
        g = gates[0]
        assert (g >= 0.0).all() and (g <= 1.0).all()

    def test_resolution_agnostic(self, device):
        m = self.AFA(dim=64, num_heads=4).to(device)
        for K in [4, 16, 64, 196]:
            x = torch.randn(2, K, 64, device=device)
            assert m(x).shape == (2, K, 64)

class TestMixFFN:
    def setup_method(self):
        from modules.mix_ffn import MixFFN
        self.MixFFN = MixFFN

    def test_output_shape(self, device):
        B, K, D = 2, 16, 64
        m = self.MixFFN(dim=D).to(device)
        x = torch.randn(B, K, D, device=device)
        assert m(x).shape == (B, K, D)

    def test_non_square_token_count(self, device):
        for K in [7, 13, 50, 100]:
            m = self.MixFFN(dim=64).to(device)
            x = torch.randn(2, K, 64, device=device)
            assert m(x).shape == (2, K, 64), f"Failed for K={K}"

    def test_residual_preserves_shape(self, device):
        m = self.MixFFN(dim=16).to(device)
        x = torch.randn(2, 8, 16, device=device)
        assert m(x).shape == x.shape

class TestLosses:
    def setup_method(self):
        from modules.losses import (
            ClusterCompactnessLoss, ReconstructionLoss, AdaptiVisionLoss
        )
        self.ClusterLoss = ClusterCompactnessLoss
        self.ReconLoss   = ReconstructionLoss
        self.FullLoss    = AdaptiVisionLoss

    def _stage_data(self, device):
        B, D = 2, 64
        configs = [(196, 16), (64, 8), (16, 4)]
        inputs, outputs, centroids, assigns = [], [], [], []
        for N, K in configs:
            z  = torch.randn(B, N, D, device=device)
            s  = torch.randn(B, K, D, device=device)
            mu = torch.randn(K, D, device=device)
            A  = torch.softmax(torch.randn(B, N, K, device=device), dim=-1)
            inputs.append(z); outputs.append(s)
            centroids.append(mu); assigns.append(A)
        return inputs, outputs, centroids, assigns

    def test_cluster_loss_nonneg(self, device):
        fn = self.ClusterLoss(num_stages=3).to(device)
        inp, out, mu, A = self._stage_data(device)
        assert fn(inp, mu, A).item() >= 0.0

    def test_recon_loss_nonneg(self, device):
        fn = self.ReconLoss(dims=[64, 64, 64], num_stages=3).to(device)
        inp, out, mu, A = self._stage_data(device)
        assert fn(inp, out, A).item() >= 0.0

    def test_full_loss_keys(self, device):
        fn = self.FullLoss(dims=[64, 64, 64], num_stages=3).to(device)
        inp, out, mu, A = self._stage_data(device)
        logits  = torch.randn(2, 1000, device=device)
        targets = torch.randint(0, 1000, (2,), device=device)
        d = fn(logits, targets, inp, out, mu, A)
        for k in ["total", "ce", "cluster", "recon"]:
            assert k in d

class TestAdaptiVision:
    def setup_method(self):
        from models.adaptivision import (
            AdaptiVision, adaptivision_light,
            adaptivision_medium, adaptivision_large
        )
        self.AdaptiVision = AdaptiVision
        self.light  = adaptivision_light
        self.medium = adaptivision_medium
        self.large  = adaptivision_large

    @pytest.mark.parametrize("builder,nc", [
        ("light", 1000), ("medium", 1000), ("light", 100),
    ])
    def test_forward_shape(self, builder, nc, device):
        model = getattr(self, builder)(num_classes=nc).to(device)
        x = torch.randn(2, 3, 224, 224, device=device)
        assert model(x).shape == (2, nc)

    def test_aux_output_keys(self, device):
        model = self.light(num_classes=10).to(device)
        x = torch.randn(2, 3, 224, 224, device=device)
        logits, aux = model(x, return_aux=True)
        for key in ["stage_inputs", "stage_outputs", "centroids", "assign_mats"]:
            assert key in aux, f"Missing key: {key}"
        assert len(aux["stage_inputs"]) == 3

    def test_no_nan_in_output(self, device):
        model = self.medium(num_classes=1000).to(device)
        x = torch.randn(4, 3, 224, 224, device=device)
        logits = model(x)
        assert not torch.isnan(logits).any()
        assert not torch.isinf(logits).any()

    def test_from_pretrained_api(self, device):
        model = self.AdaptiVision.from_pretrained("adaptivision-medium").to(device)
        x = torch.randn(1, 3, 224, 224, device=device)
        assert model(x).shape == (1, 1000)

    def test_param_count_light(self, device):
        model = self.light(num_classes=1000).to(device)
        n = sum(p.numel() for p in model.parameters()) / 1e6
        assert 10 < n < 20, f"Unexpected param count: {n:.1f}M"

    def test_gradient_flow_ca_dtc_centroids(self, device):
        model = self.light(num_classes=10).to(device)
        x = torch.randn(2, 3, 224, 224, device=device)
        logits, aux = model(x, return_aux=True)
        logits.sum().backward()
        for stage in [model.stage2, model.stage3, model.stage4]:
            assert stage.ca_dtc.centroids.grad is not None, \
                f"Centroids in {stage} must receive gradients"

    def test_full_loss_backward(self, device):
        from modules.losses import AdaptiVisionLoss
        model  = self.light(num_classes=100).to(device)
        loss_fn = AdaptiVisionLoss(
            dims=model.embed_dims[:3], num_stages=3).to(device)
        x = torch.randn(2, 3, 224, 224, device=device)
        y = torch.randint(0, 100, (2,), device=device)
        logits, aux = model(x, return_aux=True)
        d = loss_fn(logits, y,
                    aux["stage_inputs"], aux["stage_outputs"],
                    aux["centroids"],    aux["assign_mats"])
        d["total"].backward()
        grads = [p.grad for p in model.parameters() if p.grad is not None]
        assert len(grads) > 0, "Backward produced no gradients"
