import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class MixFFN(nn.Module):
  
    def __init__(
        self,
        dim: int,
        expansion: int = 4,
        drop: float = 0.0,
        dw_kernel: int = 3,
    ) -> None:
        super().__init__()
        hidden = dim * expansion

        self.norm = nn.LayerNorm(dim)
        self.fc_in = nn.Linear(dim, hidden)
     
        padding = dw_kernel // 2
        self.dw_conv = nn.Conv1d(
            hidden, hidden,
            kernel_size=dw_kernel,
            padding=padding,
            groups=hidden,
            bias=False,
        )

        self.act = nn.GELU()
        self.fc_out = nn.Linear(hidden, dim)
        self.drop = nn.Dropout(drop)

        self._init_weights()

    def _init_weights(self) -> None:
        nn.init.trunc_normal_(self.fc_in.weight, std=0.02)
        nn.init.zeros_(self.fc_in.bias)
        nn.init.trunc_normal_(self.fc_out.weight, std=0.02)
        nn.init.zeros_(self.fc_out.bias)
        nn.init.trunc_normal_(self.dw_conv.weight, std=0.02)

    def forward(self, S_prime: torch.Tensor) -> torch.Tensor:

        residual = S_prime
        x = self.norm(S_prime)            
        x = self.fc_in(x)              

        x = x.permute(0, 2, 1)          
        x = self.dw_conv(x)            
        x = x.permute(0, 2, 1)         

        x = self.act(x)
        x = self.drop(x)
        x = self.fc_out(x)             
        x = self.drop(x)

        return residual + x
