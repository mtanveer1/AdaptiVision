import torch
import torch.nn as nn
import torch.nn.functional as F


class CoordinateAwareDynamicTokenClustering(nn.Module):
    
    def __init__(
        self,
        dim: int,
        num_clusters: int,
        tau: float = 0.07,
        pos_mlp_ratio: int = 2,
    ) -> None:
        super().__init__()
        self.K = num_clusters
        self.dim = dim

        self.log_tau = nn.Parameter(torch.tensor(tau).log())

        self.centroids = nn.Parameter(torch.randn(num_clusters, dim))
        self._centroids_initialised = False

        hidden = dim * pos_mlp_ratio
        self.phi = nn.Sequential(
            nn.Linear(dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, dim),
        )
        self._init_weights()

    def _init_weights(self) -> None:
        for m in self.phi.modules():
            if isinstance(m, nn.Linear):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        nn.init.trunc_normal_(self.centroids, std=0.02)

    @torch.no_grad()
    def _init_centroids_fps(self, Z: torch.Tensor) -> None:
        if self._centroids_initialised:
            return
        z = Z[0].detach()
        N = z.shape[0]
        K = min(self.K, N)
        indices = torch.zeros(K, dtype=torch.long, device=z.device)
        distances = torch.full((N,), float("inf"), device=z.device)
        indices[0] = torch.randint(N, (1,)).item()
        for i in range(1, K):
            last = z[indices[i - 1]].unsqueeze(0)
            dist = torch.cdist(z, last).squeeze(1)
            distances = torch.minimum(distances, dist)
            indices[i] = distances.argmax()
        self.centroids.data.copy_(z[indices])
        self._centroids_initialised = True

    def forward(
        self,
        Z_in: torch.Tensor,
        P_in: torch.Tensor,
    ) -> tuple:
      
        self._init_centroids_fps(Z_in)

        tau = F.softplus(self.log_tau) + 1e-6

        Z_norm  = F.normalize(Z_in, dim=-1, eps=1e-6)              
        mu_norm = F.normalize(self.centroids, dim=-1, eps=1e-6)     
        sim     = torch.einsum("bnd,kd->bnk", Z_norm, mu_norm) / tau  
        sim     = sim.clamp(-100.0, 100.0)  

        A = F.softmax(sim, dim=-1)                                

        S_sem = torch.einsum("bnk,bnd->bkd", A, Z_in)             

        P_cluster = torch.einsum("bnk,bnd->bkd", A, P_in)          

        S_out = S_sem + self.phi(P_cluster)                        

        return S_out, P_cluster, A

CA_DTC = CoordinateAwareDynamicTokenClustering
