import torch
import torch.nn as nn
import torch.nn.functional as F


_EPS = 1e-6         

class StableLabelSmoothingCE(nn.Module):
    
    def __init__(self, num_classes: int = 1000, smoothing: float = 0.1):
        super().__init__()
        self.smoothing    = smoothing
        self.num_classes  = num_classes
        self.confidence   = 1.0 - smoothing

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        
        logits = logits.float()

        log_probs = F.log_softmax(logits, dim=-1)
        
        log_probs = log_probs.clamp(min=-100.0)

        nll = -log_probs.gather(dim=-1, index=targets.unsqueeze(1)).squeeze(1)

        smooth = -log_probs.mean(dim=-1)

        loss = self.confidence * nll + self.smoothing * smooth
        return loss.mean()

class ClusterCompactnessLoss(nn.Module):
    
    def __init__(self, num_stages: int = 3):
        super().__init__()
        self.num_stages = num_stages

    def forward(
        self,
        stage_inputs: list,   
        centroids: list,      
        assign_mats: list,    
    ) -> torch.Tensor:

        device = stage_inputs[0].device
        total  = torch.zeros(1, device=device, dtype=torch.float32)

        for S_l, mu_l, A_l in zip(stage_inputs, centroids, assign_mats):
           
            S_l  = S_l.float()
            mu_l = mu_l.float()
            A_l  = A_l.float()

            S_norm  = F.normalize(S_l,  dim=-1, eps=_EPS)   
            mu_norm = F.normalize(mu_l, dim=-1, eps=_EPS)   

            cos_sim  = torch.einsum("bnd,kd->bnk", S_norm, mu_norm)
            cos_sim  = cos_sim.clamp(-1.0 + _EPS, 1.0 - _EPS)
            cos_dist = 1.0 - cos_sim                        

            stage_loss = (A_l * cos_dist).sum(dim=-1).mean()
            total = total + stage_loss

        return (total / self.num_stages).squeeze()


class ReconstructionDecoder(nn.Module):

    def __init__(self, dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, dim * 2),
            nn.GELU(),
            nn.Linear(dim * 2, dim),
        )
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class ReconstructionLoss(nn.Module):
    def __init__(self, dims: list, num_stages: int = 3):
        super().__init__()
        self.num_stages = num_stages
        self.decoders   = nn.ModuleList(
            [ReconstructionDecoder(d) for d in dims]
        )

    def forward(
        self,
        stage_inputs:  list,  
        stage_outputs: list,   
        assign_mats:   list,   
    ) -> torch.Tensor:

        device = stage_inputs[0].device
        total  = torch.zeros(1, device=device, dtype=torch.float32)

        for decoder, S_in, S_out, A in zip(
            self.decoders, stage_inputs, stage_outputs, assign_mats
        ):
            S_in  = S_in.float()
            S_out = S_out.float()
            A     = A.float()
            pseudo = torch.bmm(A.detach(), S_out)    

            recon  = decoder(pseudo)                

            recon_norm  = F.normalize(recon,             dim=-1, eps=_EPS)
            target_norm = F.normalize(S_in.detach(),     dim=-1, eps=_EPS)

            cos_sim   = (recon_norm * target_norm).sum(dim=-1)   # (B, N)
            cos_sim   = cos_sim.clamp(-1.0 + _EPS, 1.0 - _EPS)
            stage_loss = (1.0 - cos_sim).mean()

            total = total + stage_loss

        return (total / self.num_stages).squeeze()


class AdaptiVisionLoss(nn.Module):

    def __init__(
        self,
        dims: list,
        num_stages: int     = 3,
        lambda_cluster: float = 0.01,
        lambda_recon: float   = 0.01,
        label_smoothing: float = 0.1,
        num_classes: int    = 1000,
    ):
        super().__init__()
        self.lambda_cluster = lambda_cluster
        self.lambda_recon   = lambda_recon

        self.ce           = StableLabelSmoothingCE(num_classes, label_smoothing)
        self.cluster_loss = ClusterCompactnessLoss(num_stages)
        self.recon_loss   = ReconstructionLoss(dims, num_stages)

    def forward(
        self,
        logits:        torch.Tensor,
        targets:       torch.Tensor,
        stage_inputs:  list,
        stage_outputs: list,
        centroids:     list,
        assign_mats:   list,
    ) -> dict:

        l_ce      = self.ce(logits, targets)
        l_cluster = self.cluster_loss(stage_inputs, centroids, assign_mats)
        l_recon   = self.recon_loss(stage_inputs, stage_outputs, assign_mats)

        def _safe(t: torch.Tensor, name: str) -> torch.Tensor:
            if not torch.isfinite(t):
                print(f"[WARNING] {name} is {t.item():.4f} — zeroing for this step")
                return torch.zeros_like(t)
            return t

        l_ce      = _safe(l_ce,      "l_ce")
        l_cluster = _safe(l_cluster, "l_cluster")
        l_recon   = _safe(l_recon,   "l_recon")

        total = l_ce + self.lambda_cluster * l_cluster + self.lambda_recon * l_recon

        return {
            "total":   total,
            "ce":      l_ce.detach(),
            "cluster": l_cluster.detach(),
            "recon":   l_recon.detach(),
        }
