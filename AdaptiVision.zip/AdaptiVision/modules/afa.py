import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class AdaptiveFocusAttention(nn.Module):
    
    def __init__(
        self,
        dim: int,
        num_heads: int = 8,
        reduction: int = 4,
        attn_drop: float = 0.0,
        proj_drop: float = 0.0,
        qkv_bias: bool = True,
    ) -> None:
        super().__init__()
        assert dim % num_heads == 0 
        self.num_heads = num_heads
        self.head_dim  = dim // num_heads
        self.scale     = math.sqrt(self.head_dim)

        hidden = max(dim // reduction, 1)
        self.gate = nn.Sequential(
            nn.Linear(dim, hidden, bias=False),
            nn.GELU(),
            nn.Linear(hidden, dim, bias=False),
            nn.Sigmoid(),
        )

        self.q_proj  = nn.Linear(dim, dim, bias=qkv_bias)
        self.k_proj  = nn.Linear(dim, dim, bias=qkv_bias)
        self.v_proj  = nn.Linear(dim, dim, bias=qkv_bias)
        self.out_proj = nn.Linear(dim, dim)

        self.attn_drop = nn.Dropout(attn_drop)
        self.proj_drop = nn.Dropout(proj_drop)
        self._init_weights()

    def _init_weights(self) -> None:
        for layer in [self.q_proj, self.k_proj, self.v_proj, self.out_proj]:
            nn.init.trunc_normal_(layer.weight, std=0.02)
            if layer.bias is not None:
                nn.init.zeros_(layer.bias)
        for m in self.gate.modules():
            if isinstance(m, nn.Linear):
                nn.init.trunc_normal_(m.weight, std=0.02)

    def forward(self, S_in: torch.Tensor) -> torch.Tensor:
        
        g = S_in.mean(dim=1)               

        m = self.gate(g).unsqueeze(1)      

        S_hat = S_in * m                   

        Q  = self._split_heads(self.q_proj(S_hat))   
        Kx = self._split_heads(self.k_proj(S_hat))
        V  = self._split_heads(self.v_proj(S_hat))

        attn = (Q @ Kx.transpose(-2, -1)) / self.scale   
        attn = F.softmax(attn, dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ V)                    
        x = self._merge_heads(x)          
        return self.proj_drop(self.out_proj(x))

    def _split_heads(self, x: torch.Tensor) -> torch.Tensor:
        B, K, D = x.shape
        return x.view(B, K, self.num_heads, self.head_dim).permute(0, 2, 1, 3)

    def _merge_heads(self, x: torch.Tensor) -> torch.Tensor:
        B, H, K, d_h = x.shape
        return x.permute(0, 2, 1, 3).contiguous().view(B, K, H * d_h)

AFA = AdaptiveFocusAttention
